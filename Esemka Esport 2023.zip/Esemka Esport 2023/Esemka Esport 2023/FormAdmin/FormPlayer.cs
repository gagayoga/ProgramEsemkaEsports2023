﻿using Esemka_Esport_2023.Database;
using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace Esemka_Esport_2023
{
    public partial class FormPlayer : Form
    {
        EsemkaEntities db;
        int idteam;
        public FormPlayer()
        {
            InitializeComponent();

            db = new EsemkaEntities();
        }

        private void Kondisi()
        {
            Buttonadd.Text = "Add";
            Team.Text = Company.Text = "";
        }
        private void ButtonClear_Click(object sender, EventArgs e)
        {
            Kondisi();
        }

        private void ButtonBack_Click(object sender, EventArgs e)
        {
            this.Close();
            FormHomeAdmin user = new FormHomeAdmin();
            user.Show();
        }

        private void dataGridView1_CellContentClick(object sender, DataGridViewCellEventArgs e)
        {
            DataGridViewRow row = dataGridView1.Rows[e.RowIndex];

            idteam = Convert.ToInt32(row.Cells["id"].Value);
            Team.Text = row.Cells["name"].Value.ToString();
            Company.Text = row.Cells["nick_name"].Value.ToString();
            Datebirth.Value =Convert.ToDateTime(row.Cells["birthdate"].Value);

            Buttonadd.Text = "Save";
        }

        private void Buttonadd_Click(object sender, EventArgs e)
        {
            var name = db.players.FirstOrDefault(x => x.nick_name == Company.Text.Trim());
            var date = DateTime.Now;

            if (Buttonadd.Text == "Add")
            {
                if (Team.Text.Trim() == "" || Company.Text.Trim() == "")
                {
                    MessageBox.Show("Harap isi semua inputan", "Form Player", MessageBoxButtons.OK, MessageBoxIcon.Warning);
                }else if (name != null)
                {
                    MessageBox.Show("Nickname sudah ada ", "Form Player", MessageBoxButtons.OK, MessageBoxIcon.Warning);
                }else if (Datebirth.Value > date)
                {
                    MessageBox.Show("Tanggal Lahir melebihi tanggal hari ini ", "Form Player", MessageBoxButtons.OK, MessageBoxIcon.Warning);
                }
                else
                {
                    player teamadd = new player();
                    teamadd.name = Team.Text;
                    teamadd.nick_name = Company.Text;
                    teamadd.birthdate = Datebirth.Value;
                    teamadd.created_at = DateTime.Now;

                    db.players.Add(teamadd);
                    db.SaveChanges();

                    MessageBox.Show("Input Player Succes", "Form Player", MessageBoxButtons.OK, MessageBoxIcon.Information);
                    Kondisi();
                    Loaddata();
                }
            }
            else if (Buttonadd.Text == "Save")
            {
                player addteam = db.players.Find(idteam);

                if (addteam != null)
                {
                    addteam.name = Team.Text;
                    addteam.nick_name = Company.Text;
                    addteam.birthdate = Datebirth.Value;

                    db.SaveChanges();

                    MessageBox.Show("Update Player Succes", "Form Player", MessageBoxButtons.OK, MessageBoxIcon.Information);

                    Kondisi();
                    Loaddata();
                }

            }
            else
            {

            }
        }

        // fungsi untuk menampilkan data team 
        private void Loaddata()
        {
            var team = db.players.Select(x => new
            {
                x.id,
                x.name,
                x.nick_name,
                x.birthdate
            }).ToList();

            dataGridView1.DataSource = team;
            dataGridView1.Columns[0].Visible = false;

            DataGridViewLinkColumn Link = new DataGridViewLinkColumn();
            Link.Text = "Edit";
            Link.HeaderText = "Action";
            Link.UseColumnTextForLinkValue = true;

            dataGridView1.Columns.Add(Link);
        }
        private void FormPlayer_Load(object sender, EventArgs e)
        {
            Loaddata();
        }
    }
}

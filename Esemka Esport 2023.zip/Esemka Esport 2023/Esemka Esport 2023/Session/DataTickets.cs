﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Esemka_Esport_2023
{
    internal class DataTickets
    {
        public static string home { get; set; }

        public static string away { get; set; }

        public static string time { get; set; }

        public static string ticket { get; set; }
    }
}

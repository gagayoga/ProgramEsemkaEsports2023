﻿using Esemka_Esport_2023.Database;
using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace Esemka_Esport_2023
{
    public partial class FormTransfer : Form
    {
        EsemkaEntities db;

        int idplayertransfer;
        int idplayer;
        public FormTransfer()
        {
            InitializeComponent();

            db = new EsemkaEntities();
        }

        private void ButtonBack_Click(object sender, EventArgs e)
        {
            this.Close();
            FormHomeAdmin user = new FormHomeAdmin();
            user.Show();
        }

        private void ButtonClear_Click(object sender, EventArgs e)
        {
            this.Close();
            FormPlayer user = new FormPlayer();
            user.Show();
        }

        // memunculkan data team 
        private void Loaddata()
        {
            var teamm = db.teams.ToList();
            awayteam.DataSource = teamm;
            awayteam.ValueMember = "id";
            awayteam.DisplayMember = "team_name";

            var Player = db.players.Select(x => new
            {
                x.id,
                x.nick_name
            }).ToList();

            dataGridView1.DataSource = Player;
            dataGridView1.Columns["id"].Visible = false;
        }
        private void FormTransfer_Load(object sender, EventArgs e)
        {
            Loaddata();
        }

        private void awayteam_SelectedIndexChanged(object sender, EventArgs e)
        {
            int idteam = ((team) awayteam.SelectedItem).id;

            var teamdetails = db.team_detail.Where(x=> x.team_id == idteam).Select(p => new
            {
                p.id,
                player_id =  p.player.nick_name
            }).ToList();

            dataGridView2.DataSource = teamdetails;
            dataGridView2.Columns["id"].Visible = false;
        }

        private void label2_Click(object sender, EventArgs e)
        {
            int team = ((team) awayteam.SelectedItem).id;
            var jumlahplayer = db.team_detail.FirstOrDefault(n => n.player_id == idplayertransfer);

            if (jumlahplayer != null)
            {
                MessageBox.Show("Mohon maaf player sudah ada diteam", "Player", MessageBoxButtons.OK, MessageBoxIcon.Warning);
            }
            else
            {
                team_detail model = new team_detail();
                model.team_id = team;
                model.player_id = idplayertransfer;
                model.created_at = DateTime.Now;

                db.team_detail.Add(model);
                db.SaveChanges();

                MessageBox.Show("Player berhasil di transfer", "Player", MessageBoxButtons.OK, MessageBoxIcon.Information);

                Loaddata();
            }

        }

        private void dataGridView1_CellContentClick(object sender, DataGridViewCellEventArgs e)
        {
            DataGridViewRow row = dataGridView1.Rows[e.RowIndex];
            idplayertransfer = Convert.ToInt32(row.Cells["id"].Value);
        }

        private void dataGridView2_CellContentClick(object sender, DataGridViewCellEventArgs e)
        {
            DataGridViewRow row = dataGridView2.Rows[e.RowIndex];
            idplayer = Convert.ToInt32(row.Cells["id"].Value);
        }

        private void label3_Click(object sender, EventArgs e)
        {
            team_detail data = db.team_detail.Find(idplayer);
            int team = ((team)awayteam.SelectedItem).id;
            if (data != null)
            {
                data.team_id = team;
                data.player_id = idplayertransfer;

                db.team_detail.Remove(data);
                db.SaveChanges();


                MessageBox.Show("Player berhasil di transfer", "Player", MessageBoxButtons.OK, MessageBoxIcon.Information);

                Loaddata();
            }
        }
    }
}

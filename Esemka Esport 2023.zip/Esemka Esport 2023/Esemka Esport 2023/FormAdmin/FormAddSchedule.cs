﻿using Esemka_Esport_2023.Database;
using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace Esemka_Esport_2023
{
    public partial class FormAddSchedule : Form
    {
        EsemkaEntities db;
        public FormAddSchedule()
        {
            InitializeComponent();

            db = new EsemkaEntities();
        }

        // fungsi untuk menampilkan data di combobox
        private void LoadData()
        {
            var home = db.teams.ToList();
            homeTeam.DataSource = home;
            homeTeam.ValueMember = "id";
            homeTeam.DisplayMember = "team_name";

            var away = db.teams.ToList();
            awayteam.DataSource = away;
            awayteam.ValueMember = "id";
            awayteam.DisplayMember = "team_name";
        }
        private void ButtonAdd_Click(object sender, EventArgs e)
        {
            int away = ((team)awayteam.SelectedItem).id;
            int home = ((team)homeTeam.SelectedItem).id;

            int totalhome = db.team_detail.Where(x => x.team_id == home).Count();

            int totalaway = db.team_detail.Where(c => c.team_id == away).Count();
            

            if (homeTeam.Text.Trim() == awayteam.Text.Trim())
            {
                MessageBox.Show(" Maaf Team yang sama tidak bisa bertanding", "Add Schedule Failed", MessageBoxButtons.OK, MessageBoxIcon.Warning);
            }
            else if (totalhome < 5 || totalaway < 5)
            {

                MessageBox.Show(" Maaf Team yang playernya kurang dari 5  tidak bisa bertanding", "Add Schedule Failed", MessageBoxButtons.OK, MessageBoxIcon.Warning);
            }
            else
            {
                schedule modul = new schedule();
                modul.home_team_id = home;
                modul.away_team_id = away;
                modul.time = Time.Value;
                modul.created_at = DateTime.Now;

                db.schedules.Add(modul);
                db.SaveChanges();

                MessageBox.Show("Add Schedule success", "Schedule", MessageBoxButtons.OK, MessageBoxIcon.Information);

                this.Close();
                FormHomeAdmin homeadmin = new FormHomeAdmin();
                homeadmin.Show();
            }
        }

        private void FormAddSchedule_Load(object sender, EventArgs e)
        {
            LoadData();
        }
    }
}

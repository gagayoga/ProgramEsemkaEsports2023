﻿namespace Esemka_Esport_2023
{
    partial class FormBookingTicket
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            this.dataGridView1 = new System.Windows.Forms.DataGridView();
            this.dataGridView2 = new System.Windows.Forms.DataGridView();
            this.label1 = new System.Windows.Forms.Label();
            this.Homename = new System.Windows.Forms.Label();
            this.Awayname = new System.Windows.Forms.Label();
            this.TeamHome = new System.Windows.Forms.Label();
            this.TeamAway = new System.Windows.Forms.Label();
            this.label2 = new System.Windows.Forms.Label();
            this.numericUpDown1 = new System.Windows.Forms.NumericUpDown();
            this.ButtonBooking = new System.Windows.Forms.Button();
            this.label3 = new System.Windows.Forms.Label();
            this.Labeltiket = new System.Windows.Forms.Label();
            this.ButtonBack = new System.Windows.Forms.Button();
            ((System.ComponentModel.ISupportInitialize)(this.dataGridView1)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.dataGridView2)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.numericUpDown1)).BeginInit();
            this.SuspendLayout();
            // 
            // dataGridView1
            // 
            this.dataGridView1.AllowUserToAddRows = false;
            this.dataGridView1.AutoSizeColumnsMode = System.Windows.Forms.DataGridViewAutoSizeColumnsMode.Fill;
            this.dataGridView1.ColumnHeadersHeightSizeMode = System.Windows.Forms.DataGridViewColumnHeadersHeightSizeMode.AutoSize;
            this.dataGridView1.Location = new System.Drawing.Point(73, 239);
            this.dataGridView1.Name = "dataGridView1";
            this.dataGridView1.RowHeadersWidth = 51;
            this.dataGridView1.RowTemplate.Height = 24;
            this.dataGridView1.Size = new System.Drawing.Size(364, 311);
            this.dataGridView1.TabIndex = 12;
            // 
            // dataGridView2
            // 
            this.dataGridView2.AllowUserToAddRows = false;
            this.dataGridView2.AutoSizeColumnsMode = System.Windows.Forms.DataGridViewAutoSizeColumnsMode.Fill;
            this.dataGridView2.ColumnHeadersHeightSizeMode = System.Windows.Forms.DataGridViewColumnHeadersHeightSizeMode.AutoSize;
            this.dataGridView2.Location = new System.Drawing.Point(675, 239);
            this.dataGridView2.Name = "dataGridView2";
            this.dataGridView2.RowHeadersWidth = 51;
            this.dataGridView2.RowTemplate.Height = 24;
            this.dataGridView2.Size = new System.Drawing.Size(364, 311);
            this.dataGridView2.TabIndex = 13;
            // 
            // label1
            // 
            this.label1.AutoSize = true;
            this.label1.Font = new System.Drawing.Font("ROG Fonts", 48F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label1.ForeColor = System.Drawing.Color.White;
            this.label1.Location = new System.Drawing.Point(463, 333);
            this.label1.Name = "label1";
            this.label1.Size = new System.Drawing.Size(181, 96);
            this.label1.TabIndex = 14;
            this.label1.Text = "Vs";
            // 
            // Homename
            // 
            this.Homename.AutoSize = true;
            this.Homename.Font = new System.Drawing.Font("ROG Fonts", 25.8F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.Homename.ForeColor = System.Drawing.Color.White;
            this.Homename.Location = new System.Drawing.Point(96, 123);
            this.Homename.Name = "Homename";
            this.Homename.Size = new System.Drawing.Size(310, 52);
            this.Homename.TabIndex = 15;
            this.Homename.Text = "SCHEDULE";
            this.Homename.TextAlign = System.Drawing.ContentAlignment.MiddleCenter;
            // 
            // Awayname
            // 
            this.Awayname.AutoSize = true;
            this.Awayname.Font = new System.Drawing.Font("ROG Fonts", 25.8F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.Awayname.ForeColor = System.Drawing.Color.White;
            this.Awayname.Location = new System.Drawing.Point(709, 123);
            this.Awayname.Name = "Awayname";
            this.Awayname.Size = new System.Drawing.Size(310, 52);
            this.Awayname.TabIndex = 16;
            this.Awayname.Text = "SCHEDULE";
            this.Awayname.TextAlign = System.Drawing.ContentAlignment.MiddleCenter;
            // 
            // TeamHome
            // 
            this.TeamHome.AutoSize = true;
            this.TeamHome.Font = new System.Drawing.Font("Arial Rounded MT Bold", 13.8F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.TeamHome.ForeColor = System.Drawing.Color.White;
            this.TeamHome.Location = new System.Drawing.Point(172, 185);
            this.TeamHome.Name = "TeamHome";
            this.TeamHome.Size = new System.Drawing.Size(127, 27);
            this.TeamHome.TabIndex = 17;
            this.TeamHome.Text = "Username";
            this.TeamHome.Click += new System.EventHandler(this.TeamHome_Click);
            // 
            // TeamAway
            // 
            this.TeamAway.AutoSize = true;
            this.TeamAway.Font = new System.Drawing.Font("Arial Rounded MT Bold", 13.8F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.TeamAway.ForeColor = System.Drawing.Color.White;
            this.TeamAway.Location = new System.Drawing.Point(801, 185);
            this.TeamAway.Name = "TeamAway";
            this.TeamAway.Size = new System.Drawing.Size(127, 27);
            this.TeamAway.TabIndex = 18;
            this.TeamAway.Text = "Username";
            // 
            // label2
            // 
            this.label2.AutoSize = true;
            this.label2.Font = new System.Drawing.Font("Arial Rounded MT Bold", 13.8F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label2.ForeColor = System.Drawing.Color.White;
            this.label2.Location = new System.Drawing.Point(75, 603);
            this.label2.Name = "label2";
            this.label2.Size = new System.Drawing.Size(241, 27);
            this.label2.TabIndex = 19;
            this.label2.Text = "Total Ticket Booking";
            // 
            // numericUpDown1
            // 
            this.numericUpDown1.Font = new System.Drawing.Font("Microsoft Sans Serif", 12F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.numericUpDown1.Location = new System.Drawing.Point(334, 603);
            this.numericUpDown1.Maximum = new decimal(new int[] {
            60,
            0,
            0,
            0});
            this.numericUpDown1.Name = "numericUpDown1";
            this.numericUpDown1.Size = new System.Drawing.Size(120, 30);
            this.numericUpDown1.TabIndex = 20;
            this.numericUpDown1.ValueChanged += new System.EventHandler(this.numericUpDown1_ValueChanged);
            // 
            // ButtonBooking
            // 
            this.ButtonBooking.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(224)))), ((int)(((byte)(224)))), ((int)(((byte)(224)))));
            this.ButtonBooking.FlatAppearance.BorderSize = 0;
            this.ButtonBooking.FlatAppearance.MouseOverBackColor = System.Drawing.Color.FromArgb(((int)(((byte)(122)))), ((int)(((byte)(46)))), ((int)(((byte)(168)))));
            this.ButtonBooking.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.ButtonBooking.Font = new System.Drawing.Font("Arial Rounded MT Bold", 10.2F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.ButtonBooking.Location = new System.Drawing.Point(469, 601);
            this.ButtonBooking.Name = "ButtonBooking";
            this.ButtonBooking.Size = new System.Drawing.Size(121, 36);
            this.ButtonBooking.TabIndex = 21;
            this.ButtonBooking.Text = "Book";
            this.ButtonBooking.UseVisualStyleBackColor = false;
            this.ButtonBooking.Click += new System.EventHandler(this.ButtonBooking_Click);
            // 
            // label3
            // 
            this.label3.AutoSize = true;
            this.label3.Font = new System.Drawing.Font("Arial Rounded MT Bold", 13.8F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label3.ForeColor = System.Drawing.Color.White;
            this.label3.Location = new System.Drawing.Point(846, 607);
            this.label3.Name = "label3";
            this.label3.Size = new System.Drawing.Size(150, 27);
            this.label3.TabIndex = 22;
            this.label3.Text = "Remaining : ";
            // 
            // Labeltiket
            // 
            this.Labeltiket.AutoSize = true;
            this.Labeltiket.Font = new System.Drawing.Font("Arial Rounded MT Bold", 13.8F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.Labeltiket.ForeColor = System.Drawing.Color.White;
            this.Labeltiket.Location = new System.Drawing.Point(995, 607);
            this.Labeltiket.Name = "Labeltiket";
            this.Labeltiket.Size = new System.Drawing.Size(40, 27);
            this.Labeltiket.TabIndex = 23;
            this.Labeltiket.Text = "60";
            // 
            // ButtonBack
            // 
            this.ButtonBack.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(224)))), ((int)(((byte)(224)))), ((int)(((byte)(224)))));
            this.ButtonBack.FlatAppearance.BorderSize = 0;
            this.ButtonBack.FlatAppearance.MouseOverBackColor = System.Drawing.Color.FromArgb(((int)(((byte)(122)))), ((int)(((byte)(46)))), ((int)(((byte)(168)))));
            this.ButtonBack.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.ButtonBack.Font = new System.Drawing.Font("Arial Rounded MT Bold", 13.8F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.ButtonBack.Location = new System.Drawing.Point(38, 27);
            this.ButtonBack.Name = "ButtonBack";
            this.ButtonBack.Size = new System.Drawing.Size(151, 45);
            this.ButtonBack.TabIndex = 11;
            this.ButtonBack.Text = "Back";
            this.ButtonBack.UseVisualStyleBackColor = false;
            this.ButtonBack.Click += new System.EventHandler(this.ButtonBack_Click);
            // 
            // FormBookingTicket
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(8F, 16F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(25)))), ((int)(((byte)(3)))), ((int)(((byte)(69)))));
            this.ClientSize = new System.Drawing.Size(1117, 672);
            this.Controls.Add(this.Labeltiket);
            this.Controls.Add(this.label3);
            this.Controls.Add(this.ButtonBooking);
            this.Controls.Add(this.numericUpDown1);
            this.Controls.Add(this.label2);
            this.Controls.Add(this.TeamAway);
            this.Controls.Add(this.TeamHome);
            this.Controls.Add(this.Awayname);
            this.Controls.Add(this.Homename);
            this.Controls.Add(this.label1);
            this.Controls.Add(this.dataGridView2);
            this.Controls.Add(this.dataGridView1);
            this.Controls.Add(this.ButtonBack);
            this.Name = "FormBookingTicket";
            this.StartPosition = System.Windows.Forms.FormStartPosition.CenterScreen;
            this.Text = "Form Booking Ticket -- Esemka Esports || LKS Jateng 2023";
            this.Load += new System.EventHandler(this.FormBookingTicket_Load);
            ((System.ComponentModel.ISupportInitialize)(this.dataGridView1)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.dataGridView2)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.numericUpDown1)).EndInit();
            this.ResumeLayout(false);
            this.PerformLayout();

        }

        #endregion
        private System.Windows.Forms.DataGridView dataGridView1;
        private System.Windows.Forms.DataGridView dataGridView2;
        private System.Windows.Forms.Label label1;
        private System.Windows.Forms.Label Homename;
        private System.Windows.Forms.Label Awayname;
        private System.Windows.Forms.Label TeamHome;
        private System.Windows.Forms.Label TeamAway;
        private System.Windows.Forms.Label label2;
        private System.Windows.Forms.NumericUpDown numericUpDown1;
        private System.Windows.Forms.Button ButtonBooking;
        private System.Windows.Forms.Label label3;
        private System.Windows.Forms.Label Labeltiket;
        private System.Windows.Forms.Button ButtonBack;
    }
}
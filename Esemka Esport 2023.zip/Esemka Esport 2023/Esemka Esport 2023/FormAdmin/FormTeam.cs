﻿using Esemka_Esport_2023.Database;
using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace Esemka_Esport_2023
{
    public partial class FormTeam : Form
    {
        EsemkaEntities db;

        int idteam;
        public FormTeam()
        {
            InitializeComponent();
            db = new EsemkaEntities();
        }

        // fungsi untuk menampilkan data team 
        private void Loaddata()
        {
            var team = db.teams.Select(x => new
            {
                x.id,
                x.team_name,
                x.company_name
            }).ToList();

            dataGridView1.DataSource = team;
            dataGridView1.Columns[0].Visible = false;

            DataGridViewLinkColumn Link = new DataGridViewLinkColumn();
            Link.Text = "Edit";
            Link.HeaderText = "Action";
            Link.UseColumnTextForLinkValue = true;

            dataGridView1.Columns.Add(Link);
        }
        private void FormTeam_Load(object sender, EventArgs e)
        {
            Loaddata();
        }

        private void Kondisi()
        {
            Buttonadd.Text = "Add";
            Team.Text = Company.Text = "";
        }
        private void ButtonClear_Click(object sender, EventArgs e)
        {
            Kondisi();
        }

        private void Buttonadd_Click(object sender, EventArgs e)
        {
            if (Buttonadd.Text == "Add")
            {
                if (Team.Text.Trim() == "" || Company.Text.Trim() == "")
                {
                    MessageBox.Show("Harap isi semua inputan", "Form Team", MessageBoxButtons.OK, MessageBoxIcon.Warning);
                }
                else
                {
                    team teamadd = new team();
                    teamadd.team_name = Team.Text;
                    teamadd.company_name = Company.Text;
                    teamadd.created_at = DateTime.Now;

                    db.teams.Add(teamadd);
                    db.SaveChanges();

                    MessageBox.Show("Input Team Succes", "Form Team", MessageBoxButtons.OK, MessageBoxIcon.Information);
                    Kondisi();
                    Loaddata();
                }
            }else if (Buttonadd.Text == "Save")
            {
                team addteam = db.teams.Find(idteam);

                if (addteam != null)
                {
                    addteam.team_name = Team.Text;
                    addteam.company_name = Company.Text;

                    db.SaveChanges();

                    MessageBox.Show("Update Team Succes", "Form Team", MessageBoxButtons.OK, MessageBoxIcon.Information);

                    Kondisi();
                    Loaddata();
                }

            }
            else
            {

            }
        }

        private void ButtonBack_Click(object sender, EventArgs e)
        {
            this.Close();
            FormHomeAdmin user = new FormHomeAdmin();
            user.Show();
        }

        private void dataGridView1_CellContentClick(object sender, DataGridViewCellEventArgs e)
        {
            DataGridViewRow row = dataGridView1.Rows[e.RowIndex];

            idteam =Convert.ToInt32(row.Cells["id"].Value);
            Team.Text = row.Cells["team_name"].Value.ToString();
            Company.Text = row.Cells["company_name"].Value.ToString();

            Buttonadd.Text = "Save";
        }
    }
}

﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace Esemka_Esport_2023
{
    public partial class FormPrint : Form
    {
        public FormPrint()
        {
            InitializeComponent();
        }

        private void FormPrint_Load(object sender, EventArgs e)
        {
            Loaddata();
        }

        // fungsi untuk menampilkan data dari datagrid sebekumnya
        private void Loaddata()
        {
            Labelhome.Text = DataTickets.home.ToString();
            Labelaway.Text = DataTickets.away.ToString();
            Time.Text = DataTickets.time.ToString();
            Ticket.Text = DataTickets.ticket.ToString();
        }
        // fungsi untuk kembali kehalamn sebelumnya
        private void ButtonBack_Click(object sender, EventArgs e)
        {
            this.Close();
            FormMyTicket user = new FormMyTicket();
            user.Show();

            // untuk mengkosongkan data yang simpan tadi dari datagrid sebelumnya
            DataTickets.home = DataTickets.away = DataTickets.time = "";
            DataTickets.ticket = "";

            Kondisi();
        }

        // fungsi untuk kondisi awalan form
        private void Kondisi()
        {
            Labelhome.Text = Labelaway.Text = "";
            Time.Text = Ticket.Text = "";
        }
    }
}

﻿using Esemka_Esport_2023.Database;
using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace Esemka_Esport_2023
{
    public partial class FormMyTicket : Form
    {
        EsemkaEntities db;
        public FormMyTicket()
        {
            InitializeComponent();

            db = new EsemkaEntities();
        }

        // fungsi untuk menampilkan database
        private void LoadData()
        {
            // ini variabel yang menampung data-data di database yang menggunakan join tabel untuk menampilkan datanya
            var query = from schedule_detail in db.schedule_detail
                        join schedule in db.schedules on schedule_detail.schedule_id equals schedule.id
                        where schedule_detail.user_id == Session.iduser
                        select new
                        {
                            schedule.home_team_id,
                            schedule.away_team_id,
                            schedule.time,
                            schedule_detail.total_ticket
                        };

            // menampilkan di datagrid dengan nama-nama team 
            var data = query.Select(p => new
            {
                home_team_id = db.teams.FirstOrDefault(bn => bn.id == p.home_team_id).team_name,
                away_team_id = db.teams.FirstOrDefault(bn => bn.id == p.away_team_id).team_name,
                p.time,
                p.total_ticket
            }).ToList();

            // menampilkan data di datagrid
            dataGridView1.DataSource = data;

            // menambahkan link label di datgrid
            DataGridViewLinkColumn colom = new DataGridViewLinkColumn();
            colom.Text = "Print";
            colom.HeaderText = "Action";
            colom.UseColumnTextForLinkValue = true;

            dataGridView1.Columns.Add(colom);

            // untuk mengubah header text datagrid
            dataGridView1.Columns[0].HeaderText = "Team Home";
            dataGridView1.Columns[1].HeaderText = "Team Away";
            dataGridView1.Columns[2].HeaderText = "Jadwal Match";
            dataGridView1.Columns[3].HeaderText = "Total Tickets    ";

        }
        private void FormMyTicket_Load(object sender, EventArgs e)
        {
            LoadData();
        }

        // ini fungsi untuk kembali atau back
        private void ButtonBack_Click(object sender, EventArgs e)
        {
            this.Close();
            FormUser user = new FormUser();
            user.Show();
        }

        // fungsi untuk menampilakn data yang diprint
        private void dataGridView1_CellContentClick(object sender, DataGridViewCellEventArgs e)
        {
            DataGridViewRow row = dataGridView1.Rows[e.RowIndex];

            // menyimpan data yang diklik di dalam class datatickets
            DataTickets.home = row.Cells[0].Value.ToString();
            DataTickets.away = row.Cells[1].Value.ToString();
            DataTickets.time = row.Cells[2].Value.ToString();
            DataTickets.ticket =row.Cells[3].Value.ToString();

            // menampilkan form booking ticket
            this.Hide();
            FormPrint Book = new FormPrint();
            Book.Show();
        }
    }
}

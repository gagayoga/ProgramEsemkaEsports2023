﻿using Esemka_Esport_2023.Database;
using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace Esemka_Esport_2023
{
    public partial class FormLogin : Form
    {
        // inisialisasikan object 
        EsemkaEntities db;
        public FormLogin()
        {
            InitializeComponent();

            db = new EsemkaEntities();
        }

        // membuat fungsi untuk kondisi awalan form
        private void Kondisi()
        {
            username.Text = Password.Text = Labeleror.Text = string.Empty;
            username.Text = "anton";
            Password.Text = "223311";

            // untuk admin
            //username.Text = "admin";
            //Password.Text = "admin123";
            username.Focus();
            Password.ForeColor = Color.Black;
        }
        private void FormLogin_Load(object sender, EventArgs e)
        {
            Kondisi();
        }

        //link untuk menuju halaman register jika belum mempunyai akun
        private void linkLabel1_LinkClicked(object sender, LinkLabelLinkClickedEventArgs e)
        {
            this.Hide();
            FormRegister Regis = new FormRegister();
            Regis.Show();
        }

        // membuat validasi jika inputan yang di inputkan harus diantar 6-8 karakter
        private void Password_TextChanged(object sender, EventArgs e)
        {
            String password = Password.Text.Trim();
            if(Password.Text.Trim() != string.Empty)
            {
                if (password.Length >= 4 && password.Length <= 15)
                {
                    Labeleror.Text = string.Empty;
                }
                else
                {
                    Labeleror.Text = "Panjang password harus lebih dari 6";
                }
            }
        }
        
        // fungsi untuk melihat password dengan checkbox
        private void checkBox1_CheckedChanged(object sender, EventArgs e)
        {
            if (checkBox1.Checked == true) 
            {
                Password.PasswordChar = '\0';
            }
            else
            {
                Password.PasswordChar = '*';
            }
        }

        // fungsi untuk login dengan database dan membagi hak akses berdasarkan role masing-masing user
        private void ButtonLogin_Click(object sender, EventArgs e)
        {
            // membuat validasi jika ada inputan yang kosong
            if (username.Text.Trim() == "" || Password.Text.Trim() == "") 
            {
                MessageBox.Show("Please input username or password here", "Peringatan", MessageBoxButtons.OK, MessageBoxIcon.Warning);
            }
            else
            {
                // membuat variabel yang berisi inputan
                String name = username.Text.Trim();
                String password = Password.Text.Trim();

                user userlogin = db.users.FirstOrDefault(x => x.username == name && x.password == password);
                if (userlogin != null)
                {
                    MessageBox.Show("Login Success, Welcome Back " + userlogin.username.ToString(), "Login Success", MessageBoxButtons.OK, MessageBoxIcon.Information);

                    // menyimpan data user ke dalam session;
                    Session.iduser = userlogin.id;
                    Session.name = userlogin.username;
                    Session.password = userlogin.password;
                    Session.role = userlogin.Role;
                    Session.gender = userlogin.gender;

                    // validasi role user
                    if (Session.role == true)
                    {
                        // form user jika yang login user
                        this.Hide();
                        FormUser User = new FormUser();
                        User.Show();
                    }
                    else if (Session.role == false)
                    {
                        // form admin jika yang login admin
                        this.Hide();
                        FormHomeAdmin Admin = new FormHomeAdmin();
                        Admin.Show();
                    }else
                    {
                        MessageBox.Show("Sorry your account is danger", "Peringatan", MessageBoxButtons.OK, MessageBoxIcon.Warning);
                        // jika rolenya di luar jangkauan

                        this.Close();
                        FormSplashScreen Splash = new FormSplashScreen();
                        Splash.Show();
                    }
                    Kondisi();
                }
                else
                {
                    MessageBox.Show("Login Failed, Please check username and password", "Peringatan", MessageBoxButtons.OK, MessageBoxIcon.Warning);
                    // jika datanya tidak ada atau belum punya akun
                    Kondisi();
                }
            }
        }
    }
}

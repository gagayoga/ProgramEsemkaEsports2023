﻿using Esemka_Esport_2023.Database;
using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace Esemka_Esport_2023
{
    public partial class FormRegister : Form
    {
        // inisialisasikan object 
        EsemkaEntities db;

        bool nilaiInput;
        public FormRegister()
        {
            InitializeComponent();

            db = new EsemkaEntities();
        }

        // link menuju halaman login jika sudah mempunyai akun
        private void linkLabel1_LinkClicked(object sender, LinkLabelLinkClickedEventArgs e)
        {
            this.Close();
            FormLogin login = new FormLogin();
            login.ShowDialog();
        }

        // membuat fungsi untuk kondisi awalan form
        private void Kondisi()
        {
            username.Text = Password.Text = Labeleror.Text = Cpassword.Text = string.Empty;
            username.Focus();
            Female.Checked = Male.Checked = false;
            Password.ForeColor = Color.Black;
            Cpassword.ForeColor = Color.Black;
        }
        private void FormRegister_Load(object sender, EventArgs e)
        {
            Kondisi();
        }

        //validasi panjang password minimal 6 carakter
        private void Password_TextChanged(object sender, EventArgs e)
        {
            String password = Password.Text.Trim();
            if (Password.Text.Trim() != string.Empty)
            {
                if (password.Length >= 6 && password.Length <= 15)
                {
                    Labeleror.Text = string.Empty;
                }
                else
                {
                    Labeleror.Text = "Panjang password harus lebih dari 6";
                }
            }
        }
        //validasi panjang password minimal 6 carakter dan validasi c password harus sama dengan password
        private void Cpassword_TextChanged(object sender, EventArgs e)
        {
            String password = Cpassword.Text.Trim();
            if (Cpassword.Text.Trim() != "")
            {
                if (password.Length >= 6 && password.Length <= 15)
                {
                    Labeleror.Text = string.Empty;
                }
                else
                {
                    Labeleror.Text = "Panjang password harus lebih dari 6";
                }
            }

        }

        // validasi jika inputan tanggal tidak boleh melebihi tanggal hari ini
        private void Datebirth_ValueChanged(object sender, EventArgs e)
        {
            DateTime today = DateTime.Today;  // Mendapatkan tanggal hari ini

            DateTime userDate = Datebirth.Value;  // Mendapatkan nilai input dari DateTimePicker

            if (userDate > today)
            {
                MessageBox.Show("Input tanggal tidak valid. Tanggal tidak boleh melebihi hari ini.", "Peringatan", MessageBoxButtons.OK, MessageBoxIcon.Error);
                Datebirth.Value = today;  // Mengatur ulang nilai input ke tanggal hari ini
            }
        }

        // fungsi untuk menambahkan data user
        private void ButtonRegister_Click(object sender, EventArgs e)
        {
            // membuat validasi jika ada inputan yang kosong
            if (username.Text.Trim() == "" || Password.Text.Trim() == "" || Cpassword.Text.Trim() == "")
            {
                MessageBox.Show("Please input all here", "Peringatan", MessageBoxButtons.OK, MessageBoxIcon.Warning);
            }
            else if (Cpassword.Text != Password.Text)
            {
                MessageBox.Show("Confirm password is not valid", "Peringatan", MessageBoxButtons.OK, MessageBoxIcon.Warning);
                Cpassword.ForeColor = Color.Red;
            }
            else
            {
                // membuat variabel 
               
                if (Male.Checked)
                {
                    nilaiInput = true; // Laki-laki dipilih
                }
                else if(Female.Checked)
                {
                    nilaiInput = false; // Perempuan dipilih
                }
                user useregis = new user();
                useregis.username = username.Text;
                useregis.password = Password.Text;
                useregis.birthdate = Datebirth.Value;
                useregis.gender = nilaiInput;
                useregis.Role = true;
                useregis.created_at = DateTime.Now;

                db.users.Add(useregis);
                db.SaveChanges();

                MessageBox.Show("Register Success", "Register Success", MessageBoxButtons.OK, MessageBoxIcon.Information);
                this.Close();
                FormLogin Login = new FormLogin();
                Login.Show();

                Kondisi();
            }
        }
    }
}

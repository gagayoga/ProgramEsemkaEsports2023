﻿using Esemka_Esport_2023.Database;
using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace Esemka_Esport_2023
{
    public partial class FormHomeAdmin : Form
    {
        EsemkaEntities db;
        public FormHomeAdmin()
        {
            InitializeComponent();

            db = new EsemkaEntities();
        }

        // button untuk keluar atau logout
        private void ButtonLogout_Click(object sender, EventArgs e)
        {
            if (MessageBox.Show("Apakah anda yakin logout dari peogram ini ? ", "Konfirmasi Logout", MessageBoxButtons.YesNo, MessageBoxIcon.Question) == DialogResult.Yes)
            {

                // menghapus semua data user di session
                Session.iduser = 0;
                Session.name = Session.password = string.Empty;
                Session.role = false;
                Session.gender = false;

                this.Close();
                FormLogin Login = new FormLogin();
                Login.Show();
            }
        }

        private void pictureBox1_Click(object sender, EventArgs e)
        {
            Hide();
            FormTransfer transfer = new FormTransfer();
            transfer.Show();
        }

        private void pictureBox2_Click(object sender, EventArgs e)
        {
            this.Hide();
            FormTeam team = new FormTeam();
            team.Show();
        }

        private void ButtonTickets_Click(object sender, EventArgs e)
        {
            this.Hide();
            FormAddSchedule add = new FormAddSchedule();
            add.Show();
        }


        // fungsi untuk menampilkan data ke dalam datagrid
        private void Loaddata()
        {

            var data = db.schedules.Select(ok => new
            {
                ok.id,
                home_team_id = db.teams.FirstOrDefault(bn => bn.id == ok.home_team_id).team_name,
                away_team_id = db.teams.FirstOrDefault(bn => bn.id == ok.away_team_id).team_name,
                ok.time
            }).ToList();

            DateTime today = DateTime.Today;  // Mendapatkan tanggal hari ini

            // menampilkan data yang akan bertanding dekat dari tanggal hari ini
            var data2 = data.Where(x => x.time >= today).ToList();

            dataGridView1.DataSource = data2;
            dataGridView1.Columns[0].Visible = false;

            //DataGridViewButtonColumn Button = new DataGridViewButtonColumn();
            //Button.Text = "Book";
            //Button.HeaderText = "Action";
            //Button.UseColumnTextForButtonValue = true;
            //dataGridView1.Columns.Add(Button);

            dataGridView1.Columns[1].HeaderText = "Team Home";
            dataGridView1.Columns[2].HeaderText = "Team Away";
            dataGridView1.Columns[3].HeaderText = "Jadwal Match";
        }

        private void FormHomeAdmin_Load(object sender, EventArgs e)
        {
            Loaddata();
        }
    }
}

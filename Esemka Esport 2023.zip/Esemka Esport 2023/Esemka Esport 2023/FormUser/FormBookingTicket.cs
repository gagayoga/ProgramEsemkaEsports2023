﻿using Esemka_Esport_2023.Database;
using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace Esemka_Esport_2023
{
    public partial class FormBookingTicket : Form
    {
        EsemkaEntities db;
        public FormBookingTicket()
        {
            InitializeComponent();

            db = new EsemkaEntities();
        }

        //membuat variabel yang berisi jumlah tiket yang tersedia
        int Totalticket;

        // fungsi untuk menampilkan data pertandingan
        private void LoadData()
        {
            // menampilkan teamname dari session data yang disimpan
            Homename.Text = DataMatch.home;
            Awayname.Text = DataMatch.away;

            // mencari company name berdarkan team namenhya
            var home = db.teams.FirstOrDefault(xc => xc.team_name == Homename.Text).company_name;
            var away = db.teams.FirstOrDefault(vb => vb.team_name ==  Awayname.Text).company_name;

            // menampilkan company name
            TeamAway.Text = away;
            TeamHome.Text = home;

            // membuat variabel yang berisi id team yang diambil berdasarkan nama team
            var idhome = db.teams.FirstOrDefault(xc => xc.team_name == Homename.Text).id;
            var idaway = db.teams.FirstOrDefault(xc => xc.team_name == Awayname.Text).id;

            // menampilkan data pemain berdasarkan id team
            var pemainhome = db.team_detail.Where(x=> x.team_id == idhome).Select( c => new
            {
                player_id = c.player.name
            }).ToList();
            var pemainaway = db.team_detail.Where(x => x.team_id == idaway).Select(c => new
            {
                player_id = c.player.name
            }).ToList();


            // menampilkan di datagrid pemain team
            dataGridView1.DataSource = pemainhome;
            dataGridView2.DataSource = pemainaway;

            // merubah header text di datagrid
            dataGridView1.Columns[0].HeaderText = "Player Name";
            dataGridView2.Columns[0].HeaderText = "Player Name";
        }

        private void TeamHome_Click(object sender, EventArgs e)
        {

        }

        // fungsi untuk kembali ke halaman utama
        private void ButtonBack_Click(object sender, EventArgs e)
        {
            this.Close();
            FormUser user = new FormUser();
            user.Show();
        }

        private void FormBookingTicket_Load(object sender, EventArgs e)
        {
            LoadData();
        }

        // fungsi untuk menghitung jumlah tiket
        private void Total (int awal,int akhir)
        {
            int total = awal - akhir;

            Totalticket = total;

            if (Totalticket <=0 )
            {
                Totalticket = 0;
            }
        }

        // fungsi untuk menambhakna data ke ticket
        private void ButtonBooking_Click(object sender, EventArgs e)
        {
            schedule_detail Book = new schedule_detail();
            Book.schedule_id = DataMatch.id;
            Book.user_id = Session.iduser;
            Book.total_ticket =Convert.ToInt32(numericUpDown1.Value);
            Book.created_at = DateTime.Now;

            db.schedule_detail.Add(Book);
            db.SaveChanges();

            MessageBox.Show("Book success", "Success Booking", MessageBoxButtons.OK, MessageBoxIcon.Information);

            DataMatch.id = 0;
            DataMatch.away = DataMatch.home = string.Empty;

            

            int awalan = Convert.ToInt32(Labeltiket.Text);
            int akhiran = Convert.ToInt32(numericUpDown1.Value);
            Total(awalan, akhiran);

            this.Close();
            FormUser user = new FormUser();
            user.Show();

            Labeltiket.Text = Totalticket.ToString();
            
        }

        private void numericUpDown1_ValueChanged(object sender, EventArgs e)
        {

        }
    }
}

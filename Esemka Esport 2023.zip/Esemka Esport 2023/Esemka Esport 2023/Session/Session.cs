﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Esemka_Esport_2023
{
    internal class Session
    {
        public static int iduser {  get; set; }

        public static string name { get; set; }

        public static string password { get; set; }

        public static bool role  { get; set; }

        public static bool gender { get; set; }

    }
}
